package com.example.android.newsapp1;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import java.util.ArrayList;
import java.util.List;

public class NewsAdapter extends BaseAdapter {

    private Context context;

    private List<ContentFeed> newsFeeds;

    public NewsAdapter(Context context) {
        this.context = context;
        this.newsFeeds = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return newsFeeds.size();
    }

    @Override
    public ContentFeed getItem(int position) {
        return newsFeeds.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Typeface fonts1 = Typeface.createFromAsset(context.getAssets(),
                "fonts/Lato-Light.ttf");

        Typeface fonts2 = Typeface.createFromAsset(context.getAssets(),
                "fonts/Lato-Regular.ttf");

        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.newslist, null);

            viewHolder = new ViewHolder();

            viewHolder.webTitle = (MyTextView) convertView.findViewById(R.id.webTitle);
            viewHolder.webPublicationDate = (MyTextView) convertView.findViewById(R.id.webPublicationDate);
            viewHolder.sectionName = (MyTextView) convertView.findViewById(R.id.sectionName);
            viewHolder.webUrl = (MyTextView) convertView.findViewById(R.id.webUrl);

            viewHolder.webTitle.setTypeface(fonts1);
            viewHolder.webPublicationDate.setTypeface(fonts1);

            viewHolder.webUrl.setTypeface(fonts2);
            viewHolder.sectionName.setTypeface(fonts2);

            convertView.setTag(viewHolder);
        } else {

            viewHolder = (ViewHolder) convertView.getTag();
        }

        ContentFeed item = getItem(position);

        viewHolder.webTitle.setText(item.getWebTitle());
        viewHolder.sectionName.setText(item.getSectionName());
        viewHolder.webPublicationDate.setText(item.getWebPublicationDate());
        viewHolder.webUrl.setText(item.getWebUrl());

        return convertView;
    }

    public void addFeeds(List<ContentFeed> feedArrayList) {
        this.newsFeeds = feedArrayList;
    }

    public void clear() {
        newsFeeds.clear();
    }

    private class ViewHolder {

        MyTextView sectionName;
        MyTextView webPublicationDate;
        MyTextView webTitle;
        MyTextView webUrl;
    }

    private class MyTextView {
        public void setTypeface(Typeface fonts1) {
        }


        public void setText(String webTitle) {
        }
    }

    public NewsAdapter(MainActivity mainActivity) {
    }
}
